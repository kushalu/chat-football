// var async = require("async");

module.exports = function (Club, _) {
  return {
    SetRouting: function (router) {
      router.get("/home", this.homePage);
    },

    homePage: async function (req, res) {
      //  parallel(
      // [
      // function (callback) {
      // Club.find({}, (err, result) => {
      //   // callback(err, result);
      // });
      // // }
      // // ],
      // (err, results) => {
      //   const res1 = results[0];
      //   console.log(res1);

      //   res.render("home", { title: "Footballkik - Home", data: res1 });
      // };
      // // );
      const posts = await Club.find()
        // countDocuments() gives you total count of posts
        .countDocuments()
        .then((count) => {
          totalItems = count;
          return Club.find();
          // .skip((currentPage - 1) * perPage)
          // .populate("comments", "text created")
          // .populate("comments.postedBy", "_id name")
          // .populate("postedBy", "_id name")
          // .select("_id title body created likes")
          // .limit(perPage)
          // .sort({ created: -1 });
        })
        .then((posts) => {
          // res.status(200).json(posts);
          // console.log(posts);
          res.render("home", { data: posts });
        })
        .catch((err) => console.log(err));
    },
  };
};

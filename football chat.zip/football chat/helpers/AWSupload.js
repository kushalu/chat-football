// const Aws = require("aws-sdk");
// const multer = require("multer");
// const multerS3 = require("multer-s3");

// AWS.config.update({
//   accessKeyId: "",
//   secretAccessKey: "",
//   region: "ap-south-1",
// });

// const s0 = new AWS.S3({});
// const upload = multer({
//   storage: multerrS3({
//     s3: s0,
//     bucket: "footballkick",
//     acl: "public read",
//     metadata(req, file, cb) {
//       cb(null, { fieldName: file.fieldName });
//     },
//     // key: (req, file, cb) {
//     //   cb(null,file.originalname)
//     // },key: function(req, file, cb){
//     key: function (req, file, cb) {
//       cb(null, file.originalname);
//     },

//     rename(filedName, fileName) {
//       return fileName.replace(/\w+/g, "-");
//     },
//   }),
// });

// exports.Upload = upload;

const AWS = require("aws-sdk");
const multer = require("multer");
const multerS3 = require("multer-s3");

AWS.config.update({
  accessKeyId: "",
  secretAccessKey: "",
  region: "ap-south-1",
});

const s0 = new AWS.S3({});
const upload = multer({
  storage: multerS3({
    s3: s0,
    bucket: "footballkik",
    acl: "public-read",
    metadata: function (req, file, cb) {
      cb(null, { fieldName: file.fieldname });
    },
    key: function (req, file, cb) {
      cb(null, file.originalname);
    },
  }),

  rename: function (fieldname, filename) {
    return filename.replace(/\W+/g, "-").toLowerCase();
  },
});

exports.Upload = upload;
